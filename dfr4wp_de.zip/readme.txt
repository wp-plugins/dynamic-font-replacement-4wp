=== Dynamic Font Replacement DFR4WP DE===
Contributors: Thorsten G�rke
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=8466641
Tags: dynamic font replacement, font, text, plugin, post, google, replace, replacement, seo, searchengine, sifr, 
Requires at least: 2.5
Tested up to: 2.8.4
Stable tag: 1.1 DE

Verwenden Sie Ihre eigenen ttf- oder otf-Schriftarten mit wordpress. Seo-freundlich, schnell und einfach. 
Der Quellcode Ihrer Webseite wird dabei nicht modifiziert. 

== Description ==

Verwenden Sie Ihre eigenen ttf-oder OTF-Schriftarten mit WordPress. Seo-freundlich, schnell und einfach. 
Das Plugin ersetzt den Text per Javascript im Hintergrund. Der eigentliche Quellcode bleibt intakt,
so dass Suchmaschinen keine Probleme beim Lesen und Indexieren haben.
Die Umwandlung ist schnell und einfach. Die Umwandlung geschieht ohne zus�tzliche CSS-Dateien.
Das Plugin erkennt eigenst�ndig die zu ersetzenden Tags.

== Installation ==

1. Upload des  `dfr4wp` Ordners in den Ordner `/wp-content/plugins/` 
2. Aktivieren Sie das Plugin im "Plugins"-Men� in WordPress
3. Aktivieren Sie "Dynamic Font Replacement" im Admin-Men� des Plugins.
4. Weisen Sie den gew�nschten Tags die neuen Schriftarten zu.  
5. Schauen Sie Ihre Seite an.

Achtung: Sie benutzen das Plugin auf Ihre eigene Gefahr. Es wird keinerlei Garantie �bernommen. F�r Sch�den, welche aus der Verwendung resultieren wird keine Haftung �bernommen.

== Frequently Asked Questions ==

See the helptext on the plugin-menue.

== Screenshots ==






