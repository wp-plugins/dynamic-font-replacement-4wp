=== Dynamic Font Replacement DFR4WP EN===
Contributors: Thorsten G�rke
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=8466641
Tags: dynamic font replacement, font, text, plugin, post, google, replace, replacement, seo, searchengine, sifr, 
Requires at least: 2.5
Tested up to: 2.8.4
Stable tag: 1.1 EN

Use your own ttf- or otf-fonts with wordpress. Seo-friendly, fast and easy. The sourcecode of your site will be not modify.

== Description ==

Use your own ttf- or otf-fonts with wordpress. Seo-friendly, fast and easy. The plugin display the document and replaces the text you in the background. The actual source code remains intact, 
so that search engines no problems in reading and indexing have. 
The conversion is quick and easy. It must be implemented no extra CSS files because the plug-in detects the tags 
used independently and replaced.

== Installation ==

1. Upload `dfr4wp` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Activate "Dynamic Font Replacement" in the Admin-menue.
4. Allocate the fonts to the CSS- or HTML-Tags.  
5. See your site.

Attention: You use the plugin at your own danger. No warranty is given.

== Frequently Asked Questions ==

See the helptext on the plugin-menue.

== Screenshots ==






