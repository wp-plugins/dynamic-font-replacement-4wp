<?php

$url = $_POST['url'];
header("Location: $url");

?>
